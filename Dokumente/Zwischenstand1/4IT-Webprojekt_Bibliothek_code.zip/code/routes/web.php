<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    // return ("Test");
    return inertia('Home');
});
