<script setup lang="ts">
console.log("Hello");

</script>

<template>
    <h1>Hello World!</h1>
</template>

